# ESP8266
ESP8266 altium PCB and SCH lib

- ESP8266:ESP-1   [Done!]
- ESP8266:ESP-2   [Done!]
- ESP8266:ESP-3   [Done!]
- ESP8266:ESP-4   [Done!]
- ESP8266:ESP-5   [Done!]
- ESP8266:ESP-6   [Done!]
- ESP8266:ESP-7   [Done!]
- ESP8266:ESP-8   [Done!]
- ESP8266:ESP-9   [Done!]
- ESP8266:ESP-10  [Done!]
- ESP8266:ESP-11  [Done!]
- ESP8266:ESP-12  [Done!]
- ESP8266:ESP-12E  [Done!]

Thanks to AI-Thinker,


